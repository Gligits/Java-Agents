package TPcom;

import jade.core.Agent;

public class agent extends Agent{

	protected void setup() {
		
		if (this.getLocalName().equals("A1")) 
		{
			addBehaviour (new B1());
		
		
		}
		if (this.getLocalName().equals("A2")) 
		{
			addBehaviour (new B2());
		
		
		}
		if (this.getLocalName().equals("A3")) 
		{
			addBehaviour (new B3());
		
		
		}
		
		
	}
	
	public static void main(String[] args) {
		String [] jadeArg = new String [2];
		StringBuffer SbAgent = new StringBuffer();
		SbAgent.append("A1:TPcom.agent;");
		SbAgent.append("A2:TPcom.agent;");
		SbAgent.append("A3:TPcom.agent;");

		jadeArg[0]="-gui";
		jadeArg[1]=SbAgent.toString();
		jade.Boot.main(jadeArg);
		}
}
