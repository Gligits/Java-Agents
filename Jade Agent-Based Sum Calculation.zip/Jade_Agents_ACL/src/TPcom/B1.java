package TPcom;

import java.io.IOException;
import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;

public class B1 extends OneShotBehaviour {
    
 public void action() {
        // Initialize an array to hold 10 integers
        int[] T = new int[10];

        // Fill the array with integers from 0 to 9
        for (int i = 0; i < 10; i++) { T[i] = i ;}

        // Print the contents of the array
        for (int i = 0; i < 10; i++) { System.out.print(T[i] + " ");}
        
        // Print the agent's local name
        System.out.println(this.myAgent.getLocalName());

        // Create a message to send to other agents
        ACLMessage m = new ACLMessage(ACLMessage.INFORM);
        
        try {m.setContentObject(T);} // Set the content of the message as the integer array 
        catch (IOException e) {e.printStackTrace();} // Handle exception if content cannot be set

        // Add receivers for the message (A2 and A3)
        m.addReceiver(new AID("A2", AID.ISLOCALNAME));
        m.addReceiver(new AID("A3", AID.ISLOCALNAME));
        
        // Send the message
        this.myAgent.send(m);
        
        // Blocking receive to wait for the first response
        ACLMessage m1 = this.myAgent.blockingReceive();
        int s = Integer.parseInt(m1.getContent()); // Parse the received content as an integer
        
        // Print the received sum
        System.out.print("SUM RECEIVED " + s);
        System.out.println(this.myAgent.getLocalName() + m1.getSender().toString());

        // Blocking receive to wait for the second response
        m1 = this.myAgent.blockingReceive();
        s = Integer.parseInt(m1.getContent()); // Parse the second received content as an integer

        // Print the second received sum
        System.out.print("SECOND SUM RECEIVED " + s);
        System.out.println(this.myAgent.getLocalName() + m1.getSender().toString());
  }
}


