package TPcom;

import java.io.IOException;
import jade.core.AID;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.UnreadableException;

public class B3 extends OneShotBehaviour {
    
    public void action() {
        // Initialize an array to hold 10 integers
        int[] T = new int[10];

        // Blocking receive to wait for a message from another agent
        ACLMessage m = this.myAgent.blockingReceive();

        try {T = (int[]) m.getContentObject();} // Extract the integer array from the received message
        catch (UnreadableException e) {e.printStackTrace();} // Handle exception if content cannot be read
        

        // Print the contents of the received array
        for (int i = 0; i < 10; i++) {System.out.print(T[i] + " "); }

        // Print the agent's local name
        System.out.println(this.myAgent.getLocalName());

        // Initialize a variable to hold the sum of odd numbers
        int s = 0;

        // Calculate the sum of odd numbers in the array
        for (int i = 0; i < 10; i++) 
        {if (T[i] % 2 != 0) {s = s + T[i];}}

        // Print the sum of odd numbers
        System.out.print("SUM ODD " + s);
        System.out.println(this.myAgent.getLocalName());

        // Create a message to send the sum back to another agent
        ACLMessage m1 = new ACLMessage(ACLMessage.INFORM);
        m1.setContent(Integer.toString(s)); // Set the sum as the message content
        m1.addReceiver(new AID("A1", AID.ISLOCALNAME)); // Specify the receiver
        this.myAgent.send(m1); // Send the message
    }
}
